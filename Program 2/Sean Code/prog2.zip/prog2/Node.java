/**
 * CSC 3102 - Advanced Data Structures and Algorithm Analysis
 * Dr. Kooima
 * Programming Project 2
 * 28 April 2016
 * @author seanmarino
 */
public class Node 
{
            public char character;
            public boolean visited=false;
            public Node(char l)
            {
                this.character=l;
            }
}
